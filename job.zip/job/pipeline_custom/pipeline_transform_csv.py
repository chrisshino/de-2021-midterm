from pyspark.sql import functions as f
from pipeline_step.pipeline_step import PipelineStep


class PipelineTransformCsv(PipelineStep):
    def __init__(self):
        super().__init__()
        print('transform data')

    def run(self, spark, params, df):
        df = df.withColumn("TSL/TSA %", (f.round(f.col("TSL")/f.col("TSA"),2)))
        df = df.withColumn("SSL/SSA %", (f.round(f.col("SSL")/f.col("SSA"),2)))
        df = df.withColumn("TDL/TDA %", (f.round(f.col("TDL")/f.col("TDA"),2)))
        df = df.withColumn("SGHL/SGHA %", (f.round(f.col("SGHL")/f.col("SGHA"),2)))
        return df 