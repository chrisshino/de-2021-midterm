from pyspark.sql import functions as f
from pipeline_step.pipeline_step import PipelineStep


class PipelineSaveCsv(PipelineStep):
    def __init__(self):
        super().__init__()
        print('save data')

    def run(self, spark, params, df):
        output_path = params.args['output_path']
        df.write.option('header','true').csv(output_path)
        return df 